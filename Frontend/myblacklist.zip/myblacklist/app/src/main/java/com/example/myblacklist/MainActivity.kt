package com.example.myblacklist

import android.os.Bundle
import android.widget.*
import android.widget.ListView
import android.widget.SearchView
import android.widget.Toast
import android.widget.AdapterView.OnItemClickListener
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var addButton: Button
    private lateinit var itemList: MutableList<Item>
    private lateinit var adapter: ArrayAdapter<Item>
    private lateinit var searchView: SearchView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        searchView = findViewById(R.id.searchListView)
        listView = findViewById(R.id.listView)
        listView.isClickable = true
        addButton = findViewById(R.id.addButton)
        itemList = mutableListOf()
        adapter = ArrayAdapter(this, R.layout.listitem, R.id.itemTextView, itemList)
        listView.adapter = adapter
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                if (itemList.contains(Item(query))) {
                    adapter.filter.filter(query)
                } else {
                    Toast.makeText(this@MainActivity, "No Match found", Toast.LENGTH_LONG).show()
                }
                return false
            }
            override fun onQueryTextChange(newText: String): Boolean {
                adapter.filter.filter(newText)
                return false
            }
        })

        listView.onItemClickListener =
            OnItemClickListener { parent, view, position, id ->
                showRemoveItemPrompt(position)
            }

        addButton.setOnClickListener {
            showAddItemPrompt()
        }


        // Add some sample items
        itemList.add(Item("this is a phone number"))
        itemList.add(Item("this is another phone number"))
        itemList.add(Item("this is a totally different phone number for sure"))
        adapter.notifyDataSetChanged()


    }


    private fun showRemoveItemPrompt(x: Int) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Do you want to remove ${listView.getItemAtPosition(x)}?")

        builder.setPositiveButton("Remove") { _, _ ->
            removeItem(x)
        }

        builder.setNegativeButton("Cancel") { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }

    private fun showAddItemPrompt() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Add Item")

        val input = EditText(this)
        builder.setView(input)

        builder.setPositiveButton("Add") { _, _ ->
            val itemName = input.text.toString()
            addItem(itemName)
        }

        builder.setNegativeButton("Cancel") { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }

    private fun addItem(name: String) {
        itemList.add(Item(name))
        adapter.notifyDataSetChanged()
    }

    private fun removeItem(position: Int) {
        itemList.removeAt(position)
        adapter.notifyDataSetChanged()
    }
}
