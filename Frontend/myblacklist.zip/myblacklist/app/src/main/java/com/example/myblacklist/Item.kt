package com.example.myblacklist

public data class Item(public val name: String){}