import pandas as pd

dataset = pd.read_csv("./Backend/Datasets/spam.csv", encoding="latin1")