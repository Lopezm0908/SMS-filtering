import java.io.IOException;

public class LRTesting {
    
    public static void main (String[] args) throws IOException {
        TestMessage testing = new TestMessage();

        String message = "";
        testing.Test(message);
    }
}
