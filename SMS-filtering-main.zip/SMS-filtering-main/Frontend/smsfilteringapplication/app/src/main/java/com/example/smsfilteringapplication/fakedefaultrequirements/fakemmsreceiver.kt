package com.example.smsfilteringapplication.fakedefaultrequirements

class fakemmsreceiver {
}