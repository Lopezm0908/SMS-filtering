package com.example.smsfilteringapplication.fakedefaultrequirements

class fakepackagedelivery {
}